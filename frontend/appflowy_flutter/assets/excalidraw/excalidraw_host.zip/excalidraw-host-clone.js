import{b as r}from"./excalidraw-host-_baseUniq.js";var e=4;function a(o){return r(o,e)}export{a as c};
